/* This file is a part of groinc
 * Copyright 2006 Sarzyniec Luc <olbat@xiato.com>
 * This software is released under GPL the license
 * see the COPYING file for more informations */

#ifndef _CHECK_OPTIONS_H
#define _CHECK_OPTIONS_H

int check_options();

#endif

